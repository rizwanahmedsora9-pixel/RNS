# Hotspot Billing Gateway (Infinix X650C, rooted)

## What this is
Router1 (ISP) -> Phone (NAT + captive portal + voucher billing) -> Router2 -> Users

## STILL UNCONFIRMED — must check before deploying
Whether your chip supports simultaneous WiFi-client (STA, to Router1) + WiFi-AP
(to Router2) mode. Run this with WiFi on and connected, then hotspot also enabled:

    su -c "ip link"
    su -c "cat /sys/class/net/wlan0/operstate"
    su -c "cat /sys/class/net/ap0/operstate"
    dumpsys wifi | grep -i "mode\|concurrent"

If ap0 won't come up while wlan0 is connected to Router1, switch LAN_IF in both
scripts/setup_network.sh and scripts/bandwidth_control.sh to a USB-OTG Ethernet
adapter's interface name (usually usb0 or eth0) instead of ap0, and connect
Router2 to the phone via that adapter instead of over WiFi.

## Files
- `scripts/setup_network.sh` — NAT, iptables captive-portal redirect, dnsmasq DHCP,
  MAC/IP authorize+deauthorize hooks. Push to `/data/local/tmp/` (the app does
  this automatically from its bundled assets on first run).
- `scripts/bandwidth_control.sh` — tc/htb per-IP bandwidth shaping.
- `app/` — Android Studio project (Kotlin). Open this folder directly in
  Android Studio; it's a standard Gradle module layout.

## Core logic
- `VoucherManager.kt` — redemption + the single-device binding rule: a voucher's
  first successful redemption locks in the requesting MAC address (`boundMac`)
  and assigns it a static IP from `IpPool`. Any later redemption attempt with a
  *different* MAC is rejected (`AlreadyUsedOnAnotherDevice`); the same MAC
  reconnecting is allowed through again.
- `CaptivePortalServer.kt` — NanoHTTPD server on 10.66.0.1:8080. iptables DNATs
  all unauthenticated HTTP(S) on the LAN interface to it. Handles the OS-specific
  probe URLs (`generate_204`, `hotspot-detect.html`, `ncsi.txt`) so the "Sign in
  to network" prompt pops automatically on Android/iOS/Windows.
- `ArpResolver.kt` — resolves a connecting client's MAC from its LAN IP via
  `/proc/net/arp` at redemption time.

## To build
1. Open `app/` in Android Studio (Giraffe+), let Gradle sync.
2. `adb install` the resulting APK on the rooted phone, grant it root when
   Magisk prompts.
3. On first launch it copies the two shell scripts to `/data/local/tmp`,
   brings up NAT + DHCP + iptables, and starts the portal server.

## Not yet built (tell me which to do next)
- Admin UI for generating/viewing vouchers (currently only `VoucherManager.generateBatch()`
  exists as a callable function — no screen wired up yet)
- WorkManager periodic job calling `voucherManager.sweepExpired()`
- Data usage tracking per session (bytesUp/bytesDown in `UserSession` are defined
  but nothing populates them yet — would read `/proc/net/xt_qtaguid` or iptables
  byte counters per IP)
- User profiling screen / export
- Handling dnsmasq lease expiry cleanup vs voucher expiry (currently independent)

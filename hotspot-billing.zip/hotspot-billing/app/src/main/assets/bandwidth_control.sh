#!/system/bin/sh
# bandwidth_control.sh
# Per-client bandwidth shaping using tc/htb on the LAN interface.
# Each voucher plan maps to a class with a rate ceiling; a client's traffic
# is filtered into its class by destination IP (the static IP the app assigned).
#
# USAGE:
#   su -c "sh bandwidth_control.sh init"
#   su -c "sh bandwidth_control.sh add <ip> <class_id_decimal> <rate_kbit> <ceil_kbit>"
#   su -c "sh bandwidth_control.sh remove <ip> <class_id_decimal>"

LAN_IF="ap0"   # match setup_network.sh

init() {
    tc qdisc del dev $LAN_IF root 2>/dev/null
    tc qdisc add dev $LAN_IF root handle 1: htb default 999
    tc class add dev $LAN_IF parent 1: classid 1:1 htb rate 1000mbit ceil 1000mbit
    # default/unclassified bucket - very low, catches anything not explicitly authorized
    tc class add dev $LAN_IF parent 1:1 classid 1:999 htb rate 64kbit ceil 128kbit
}

add() {
    IP="$1"; CID="$2"; RATE="$3"; CEIL="$4"
    tc class add dev $LAN_IF parent 1:1 classid 1:$CID htb rate ${RATE}kbit ceil ${CEIL}kbit
    tc filter add dev $LAN_IF protocol ip parent 1:0 prio 1 u32 match ip dst ${IP}/32 flowid 1:$CID
}

remove() {
    IP="$1"; CID="$2"
    tc filter del dev $LAN_IF protocol ip parent 1:0 prio 1 u32 match ip dst ${IP}/32 flowid 1:$CID 2>/dev/null
    tc class del dev $LAN_IF classid 1:$CID 2>/dev/null
}

case "$1" in
    init) init ;;
    add) add "$2" "$3" "$4" "$5" ;;
    remove) remove "$2" "$3" ;;
    *) echo "Usage: $0 {init|add <ip> <class_id> <rate_kbit> <ceil_kbit>|remove <ip> <class_id>}" ;;
esac

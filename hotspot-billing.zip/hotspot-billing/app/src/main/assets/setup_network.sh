#!/system/bin/sh
# setup_network.sh
# Run as root on the Infinix phone. Sets up:
#  - IP forwarding + NAT from LAN interface -> WAN interface
#  - iptables mark-based captive portal redirect for un-authenticated MACs
#  - dnsmasq as DHCP server for the LAN interface
#
# USAGE: su -c "sh /data/local/tmp/setup_network.sh start|stop"
#
# Interfaces (edit to match your actual setup once confirmed):
WAN_IF="wlan0"      # phone's WiFi client connection to Router1 (ISP)
LAN_IF="ap0"        # phone's hotspot AP interface serving Router2 -> users
                     # If STA+AP concurrent mode is NOT supported on this chip,
                     # replace LAN_IF with the USB-OTG ethernet interface (e.g. eth0/usb0)

LAN_SUBNET="10.66.0.0/24"
LAN_IP="10.66.0.1"
PORTAL_PORT="8080"          # port the Kotlin app's NanoHTTPD captive portal listens on
PORTAL_MARK="0x1"           # iptables mark for "unauthenticated" traffic
DNSMASQ_CONF="/data/local/tmp/dnsmasq_hotspot.conf"
DNSMASQ_LEASES="/data/local/tmp/dnsmasq.leases"
DNSMASQ_PID="/data/local/tmp/dnsmasq_hotspot.pid"

# This file is maintained by the app: one line per authenticated device,
# format: <mac> <static_ip>
AUTHORIZED_FILE="/data/local/tmp/authorized_macs.txt"

start() {
    echo "[*] Enabling IP forwarding"
    echo 1 > /proc/sys/net/ipv4/ip_forward

    echo "[*] Bringing up $LAN_IF with $LAN_IP"
    ip addr flush dev $LAN_IF
    ip addr add ${LAN_IP}/24 dev $LAN_IF
    ip link set $LAN_IF up

    echo "[*] Flushing old rules"
    iptables -F
    iptables -t nat -F
    iptables -t mangle -F

    echo "[*] NAT: LAN -> WAN"
    iptables -t nat -A POSTROUTING -o $WAN_IF -j MASQUERADE
    iptables -A FORWARD -i $LAN_IF -o $WAN_IF -j ACCEPT
    iptables -A FORWARD -i $WAN_IF -o $LAN_IF -m state --state RELATED,ESTABLISHED -j ACCEPT

    echo "[*] Allow authorized MAC/IP pairs to pass through unredirected"
    if [ -f "$AUTHORIZED_FILE" ]; then
        while read -r mac ip; do
            [ -z "$mac" ] && continue
            iptables -t nat -I PREROUTING -i $LAN_IF -m mac --mac-source "$mac" -j RETURN
            iptables -I FORWARD -i $LAN_IF -m mac --mac-source "$mac" -s "$ip" -j ACCEPT
        done < "$AUTHORIZED_FILE"
    fi

    echo "[*] Captive portal redirect for everyone else (HTTP -> local portal)"
    iptables -t nat -A PREROUTING -i $LAN_IF -p tcp --dport 80 -j DNAT --to-destination ${LAN_IP}:${PORTAL_PORT}
    iptables -t nat -A PREROUTING -i $LAN_IF -p tcp --dport 443 -j DNAT --to-destination ${LAN_IP}:${PORTAL_PORT}

    echo "[*] Block LAN clients from reaching WAN until authorized (default deny)"
    iptables -P FORWARD DROP
    iptables -A FORWARD -i $LAN_IF -o $WAN_IF -j ACCEPT

    echo "[*] Starting dnsmasq for DHCP on $LAN_IF"
    dnsmasq \
        --interface=$LAN_IF \
        --bind-interfaces \
        --dhcp-range=10.66.0.50,10.66.0.250,12h \
        --dhcp-option=3,${LAN_IP} \
        --dhcp-option=6,${LAN_IP} \
        --dhcp-leasefile=$DNSMASQ_LEASES \
        --pid-file=$DNSMASQ_PID \
        --conf-file=/dev/null \
        --no-daemon &

    echo "[*] Network setup complete."
}

stop() {
    echo "[*] Stopping dnsmasq"
    [ -f "$DNSMASQ_PID" ] && kill "$(cat $DNSMASQ_PID)" 2>/dev/null

    echo "[*] Flushing iptables"
    iptables -F
    iptables -t nat -F
    iptables -t mangle -F
    iptables -P FORWARD ACCEPT

    echo "[*] Done."
}

# Called by the app whenever a voucher is redeemed, to allow that MAC/IP through
# without restarting the whole ruleset.
authorize() {
    MAC="$1"
    IP="$2"
    iptables -t nat -I PREROUTING -i $LAN_IF -m mac --mac-source "$MAC" -j RETURN
    iptables -I FORWARD -i $LAN_IF -m mac --mac-source "$MAC" -s "$IP" -j ACCEPT
    echo "$MAC $IP" >> "$AUTHORIZED_FILE"
}

# Called by the app to revoke access (voucher expired / reused on 2nd device)
deauthorize() {
    MAC="$1"
    iptables -t nat -D PREROUTING -i $LAN_IF -m mac --mac-source "$MAC" -j RETURN 2>/dev/null
    iptables -D FORWARD -i $LAN_IF -m mac --mac-source "$MAC" -j ACCEPT 2>/dev/null
    grep -v "^$MAC " "$AUTHORIZED_FILE" > "${AUTHORIZED_FILE}.tmp" 2>/dev/null
    mv "${AUTHORIZED_FILE}.tmp" "$AUTHORIZED_FILE" 2>/dev/null
}

case "$1" in
    start) start ;;
    stop) stop ;;
    authorize) authorize "$2" "$3" ;;
    deauthorize) deauthorize "$2" ;;
    *) echo "Usage: $0 {start|stop|authorize <mac> <ip>|deauthorize <mac>}" ;;
esac

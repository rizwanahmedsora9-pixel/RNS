package com.hotspot.billing.net

import com.hotspot.billing.db.AppDatabase
import com.hotspot.billing.db.UserSession
import com.hotspot.billing.db.Voucher
import com.hotspot.billing.db.VoucherStatus
import com.hotspot.billing.util.RootShell
import java.util.concurrent.atomic.AtomicInteger

sealed class RedeemResult {
    data class Success(val ip: String, val expiresAt: Long) : RedeemResult()
    object InvalidCode : RedeemResult()
    object AlreadyUsedOnAnotherDevice : RedeemResult()
    object Expired : RedeemResult()
    object PoolExhausted : RedeemResult()
}

class VoucherManager(private val db: AppDatabase) {

    private val classIdCounter = AtomicInteger(100)

    /**
     * Called by the captive portal when a user submits a voucher code.
     * requestingMac = MAC address of the device making the request (read from
     * the ARP table / dnsmasq lease, keyed by the client's source IP on the LAN).
     */
    @Synchronized
    fun redeem(code: String, requestingMac: String): RedeemResult {
        val voucher = db.voucherDao().findByCode(code.trim().uppercase())
            ?: return RedeemResult.InvalidCode

        val now = System.currentTimeMillis()

        return when (voucher.status) {
            VoucherStatus.UNUSED -> activateFresh(voucher, requestingMac, now)

            VoucherStatus.ACTIVE -> {
                if (voucher.expiresAt != null && now > voucher.expiresAt) {
                    expireVoucher(voucher)
                    return RedeemResult.Expired
                }
                // Core rule: voucher is already bound to a different MAC -> reject
                if (voucher.boundMac != null && voucher.boundMac != requestingMac) {
                    RedeemResult.AlreadyUsedOnAnotherDevice
                } else {
                    // Same device re-submitting (e.g. reconnect) -> just re-authorize
                    RedeemResult.Success(voucher.assignedIp!!, voucher.expiresAt!!)
                }
            }

            VoucherStatus.EXPIRED -> RedeemResult.Expired
        }
    }

    private fun activateFresh(voucher: Voucher, mac: String, now: Long): RedeemResult {
        val ip = IpPool.allocate() ?: return RedeemResult.PoolExhausted
        val expiresAt = now + voucher.durationMinutes * 60_000L
        val classId = classIdCounter.incrementAndGet()

        val updated = voucher.copy(
            status = VoucherStatus.ACTIVE,
            boundMac = mac,
            assignedIp = ip,
            activatedAt = now,
            expiresAt = expiresAt,
            classId = classId
        )
        db.voucherDao().upsert(updated)

        // Bind MAC<->IP at the firewall level (only this MAC+IP pair can pass NAT)
        RootShell.authorizeMac(mac, ip)
        // Apply the plan's bandwidth cap to that IP
        RootShell.addBandwidthClass(ip, classId, voucher.rateKbit, voucher.ceilKbit)

        db.sessionDao().insert(
            UserSession(mac = mac, ip = ip, voucherCode = voucher.code, connectedAt = now)
        )

        return RedeemResult.Success(ip, expiresAt)
    }

    private fun expireVoucher(voucher: Voucher) {
        db.voucherDao().upsert(voucher.copy(status = VoucherStatus.EXPIRED))
        voucher.boundMac?.let { RootShell.deauthorizeMac(it) }
        voucher.assignedIp?.let { ip ->
            IpPool.release(ip)
            voucher.classId?.let { RootShell.removeBandwidthClass(ip, it) }
        }
    }

    /** Call periodically (e.g. WorkManager every minute) to sweep expired vouchers. */
    fun sweepExpired() {
        val now = System.currentTimeMillis()
        db.voucherDao().getExpired(now).forEach { expireVoucher(it) }
    }

    /** Generates a batch of fresh voucher codes for a given plan. */
    fun generateBatch(count: Int, planName: String, durationMinutes: Int, rateKbit: Int, ceilKbit: Int): List<String> {
        val codes = mutableListOf<String>()
        repeat(count) {
            val code = generateCode()
            db.voucherDao().upsert(
                Voucher(
                    code = code,
                    planName = planName,
                    durationMinutes = durationMinutes,
                    rateKbit = rateKbit,
                    ceilKbit = ceilKbit
                )
            )
            codes.add(code)
        }
        return codes
    }

    private fun generateCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no ambiguous chars (0/O, 1/I)
        fun block() = (1..4).map { chars.random() }.joinToString("")
        return "${block()}-${block()}"
    }
}

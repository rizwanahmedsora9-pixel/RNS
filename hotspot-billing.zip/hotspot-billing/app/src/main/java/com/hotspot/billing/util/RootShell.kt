package com.hotspot.billing.util

import com.topjohnwu.superuser.Shell

/**
 * Thin wrapper around libsu for running rooted shell commands.
 * Add to build.gradle: implementation 'com.github.topjohnwu.libsu:core:5.2.1'
 */
object RootShell {

    private const val SCRIPT_DIR = "/data/local/tmp"

    fun isRootAvailable(): Boolean = Shell.getShell().isRoot

    fun run(cmd: String): Shell.Result = Shell.cmd(cmd).exec()

    fun startNetwork() = run("sh $SCRIPT_DIR/setup_network.sh start")

    fun stopNetwork() = run("sh $SCRIPT_DIR/setup_network.sh stop")

    fun authorizeMac(mac: String, ip: String) =
        run("sh $SCRIPT_DIR/setup_network.sh authorize $mac $ip")

    fun deauthorizeMac(mac: String) =
        run("sh $SCRIPT_DIR/setup_network.sh deauthorize $mac")

    fun initBandwidth() = run("sh $SCRIPT_DIR/bandwidth_control.sh init")

    fun addBandwidthClass(ip: String, classId: Int, rateKbit: Int, ceilKbit: Int) =
        run("sh $SCRIPT_DIR/bandwidth_control.sh add $ip $classId $rateKbit $ceilKbit")

    fun removeBandwidthClass(ip: String, classId: Int) =
        run("sh $SCRIPT_DIR/bandwidth_control.sh remove $ip $classId")

    /** Reads current DHCP leases to map IP -> MAC for clients currently on the LAN. */
    fun readLeases(): List<String> =
        run("cat /data/local/tmp/dnsmasq.leases").out
}

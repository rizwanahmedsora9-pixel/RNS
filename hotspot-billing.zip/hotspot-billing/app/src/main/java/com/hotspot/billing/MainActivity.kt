package com.hotspot.billing

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hotspot.billing.db.AppDatabase
import com.hotspot.billing.net.VoucherManager
import com.hotspot.billing.portal.CaptivePortalServer
import com.hotspot.billing.util.RootShell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var portalServer: CaptivePortalServer
    private lateinit var voucherManager: VoucherManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = AppDatabase.get(this)
        voucherManager = VoucherManager(db)

        CoroutineScope(Dispatchers.IO).launch {
            // 1. Push scripts to /data/local/tmp (bundled as raw assets - see assets/ dir)
            deployScripts()

            // 2. Confirm root
            if (!RootShell.isRootAvailable()) {
                runOnUiThread { /* show "root not granted" error in UI */ }
                return@launch
            }

            // 3. Bring up NAT / iptables / dnsmasq
            RootShell.startNetwork()
            RootShell.initBandwidth()

            // 4. Start the captive portal HTTP server
            portalServer = CaptivePortalServer(voucherManager)
            portalServer.start()
        }
    }

    private fun deployScripts() {
        val scripts = listOf("setup_network.sh", "bandwidth_control.sh")
        for (name in scripts) {
            val input = assets.open(name)
            val outFile = "/data/local/tmp/$name"
            val tmpLocal = java.io.File(cacheDir, name)
            input.copyTo(tmpLocal.outputStream())
            RootShell.run("cp ${tmpLocal.absolutePath} $outFile && chmod 755 $outFile")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::portalServer.isInitialized) portalServer.stop()
        RootShell.stopNetwork()
    }
}

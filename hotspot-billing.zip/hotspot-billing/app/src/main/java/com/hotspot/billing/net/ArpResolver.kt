package com.hotspot.billing.net

import com.hotspot.billing.util.RootShell

/**
 * Captive portal requests arrive with a source IP (the client's DHCP-leased IP).
 * We need the MAC address to bind the voucher to. Read it from /proc/net/arp
 * (populated automatically once the client has sent any packet, which it has
 * by the time it hits the portal).
 */
object ArpResolver {

    fun macForIp(ip: String): String? {
        val result = RootShell.run("cat /proc/net/arp")
        for (line in result.out) {
            val parts = line.trim().split(Regex("\\s+"))
            // format: IP address / HW type / Flags / HW address / Mask / Device
            if (parts.size >= 4 && parts[0] == ip) {
                val mac = parts[3]
                if (mac != "00:00:00:00:00:00") return mac.lowercase()
            }
        }
        return null
    }
}
